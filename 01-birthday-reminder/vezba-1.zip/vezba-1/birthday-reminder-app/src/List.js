import React, { useState } from 'react';
import data from './data';
import Card from './Card';

const List = () => {
  const [people, setPeople] = useState(data);
  const removePeople = () => {
    setPeople([]);
  };
  return (
    <section className='cards'>
      <h1 className='title'>{people.length} birthdays today</h1>
      {people.map((person) => {
        return <Card key={person.id} {...person} />;
      })}
      <button className='btn' type='button' onClick={removePeople}>
        Clear All
      </button>
    </section>
  );
};

export default List;
