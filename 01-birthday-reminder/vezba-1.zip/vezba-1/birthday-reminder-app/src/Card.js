import React from 'react';

const Card = ({ name, age, image }) => {
  return (
    <div className='card'>
      <img className='card__person-icon' src={image} alt='' />
      <section>
        <h4 className='card__person-name'>{name}</h4>
        <p className='card__person-age'>{age} years</p>
      </section>
    </div>
  );
};

export default Card;
