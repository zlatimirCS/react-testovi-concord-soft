import './App.css';
import List from './List';

const App = () => {
  return (
    <div className='wrapper'>
      <div className='background'>
        <List />
      </div>
    </div>
  );
};

export default App;
