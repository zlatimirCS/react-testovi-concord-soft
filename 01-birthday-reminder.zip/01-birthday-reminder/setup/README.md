## Uputstvo

klonirati sve projekte
git clone https://github.com/zlatimirCS/react-testovi-concord-soft.git

navigirati u folder /01-birthday-reminder/setup

npm install

kreirati svoj branch
git checkout -b {naziv-brancha}

git push

github username: zlatimir_rk@yahoo.com

Ocekivani rezultat
https://react-projects-1-birthday-reminder.netlify.app/
